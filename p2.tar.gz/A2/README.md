CSC360-A2
=========
Author: Evan Murphy
Programming Assignment 2
CSC 360 Fall 2014, Jianping Pan

Specs - https://github.com/esmurphy7/CSC360-A2/blob/master/p2.pdf?raw=true

Instructions:
This project requires the singly linked list library "slist.h"

To compile the project and create executable "mts.exe"
	$ make

To run the project
	$ ./mts.exe <input.txt> <ntrains>
	